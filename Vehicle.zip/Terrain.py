from panda3d.core import BitMask32
from panda3d.core import Filename
from panda3d.core import PNMImage
from panda3d.core import GeoMipTerrain
from panda3d.bullet import BulletWorld
from panda3d.bullet import BulletRigidBodyNode
from panda3d.bullet import BulletHeightfieldShape
from panda3d.bullet import ZUp

class Terrain(object):

  def __init__(self, main, base, render):
    # Heightfield (static)
    height = 8.0

    img = PNMImage(Filename('models/HeightMap.png'))
    shape = BulletHeightfieldShape(img, height, ZUp)
    shape.setUseDiamondSubdivision(True)
    self.rigidNode = BulletRigidBodyNode('Heightfield')
    self.rigidNode.notifyCollisions(False)
    np = main.worldNP.attachNewNode(self.rigidNode)
    np.node().addShape(shape)
    np.setPos(0, 0, 0)
    np.setCollideMask(BitMask32.allOn())
    np.node().notifyCollisions(False)

    main.world.attachRigidBody(np.node())

    self.hf = np.node() # To enable/disable debug visualisation

    self.terrain = GeoMipTerrain('terrain')
    self.terrain.setHeightfield(img)

    self.terrain.setBlockSize(32)
    self.terrain.setNear(50)
    self.terrain.setFar(100)
    self.terrain.setFocalPoint(base.camera)

    rootNP = self.terrain.getRoot()
    rootNP.reparentTo(render)
    rootNP.setSz(8.0)

    offset = img.getXSize() / 2.0 - 0.5
    rootNP.setPos(-offset, -offset, -height / 2.0)

    self.terrain.generate()

  def toggleHeightfield(self):
    self.hf.setDebugEnabled(not self.hf.isDebugEnabled())
