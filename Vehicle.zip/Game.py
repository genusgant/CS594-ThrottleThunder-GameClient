import sys
import math
import direct.directbase.DirectStart

from direct.showbase.DirectObject import DirectObject
from direct.showbase.InputStateGlobal import inputState

from panda3d.core import AmbientLight
from panda3d.core import DirectionalLight
from panda3d.core import Vec2
from panda3d.core import Vec3
from panda3d.core import Vec4
from panda3d.core import LVecBase3
from panda3d.core import Point3
from panda3d.core import TransformState
from panda3d.core import BitMask32
from panda3d.core import PandaNode
from panda3d.core import NodePath

from panda3d.bullet import BulletWorld
from panda3d.bullet import BulletPlaneShape
from panda3d.bullet import BulletBoxShape
from panda3d.bullet import BulletRigidBodyNode
from panda3d.bullet import BulletDebugNode
from panda3d.bullet import BulletHeightfieldShape
from panda3d.bullet import ZUp

from Terrain import Terrain
from Vehicle import Vehicle
from Obstruction import Obstruction

from threading import Thread
from time import sleep

import re

from pandac.PandaModules import loadPrcFileData
loadPrcFileData('', 'bullet-enable-contact-events true')

def getDimensions(nPath):
    pt1, pt2 = nPath.getTightBounds()
    xDim = pt2.getX() - pt1.getX()
    yDim = pt2.getY() - pt1.getY()
    zDim = pt2.getZ() - pt1.getZ()
    return [xDim,yDim,zDim]

path = ['f', 'f', 'f', 'f', 'f', 'f', 'f', 'f', 'f', 'f', 'f', 'f', 'f', 'f', 'f', 'f',
        # 'f', 'f', 'f', 'f', 'f', 'f', 'f', 'f', 'f', 'f', 'f', 'f', 'f', 'f', 'f', 'f',
        # 'f', 'f', 'f', 'f', 'f', 'f', 'f', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b',
        # 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b','b', 'b', 'b', 'b', 'b', 'b',
        'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b','b', 'b', 'b', 'b', 'b', 'b',
        'f', 'f', 'f', 'f', 'f', 'f', 'f', 'f', 'f', 'f', 'f', 'f', 'f', 'f', 'f', 'f',
        'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b','b', 'b', 'b', 'b', 'b', 'b']

class Game(DirectObject):

  def __init__(self):

    self.nodeFilterList = []
    self.collisionThreadSet = []
    self.setupLights()
    # Input
    self.accept('escape', self.doExit)
    self.accept('r', self.doReset)
    self.accept('f1', self.toggleWireframe)
    self.accept('f2', self.toggleTexture)
    self.accept('f3', self.toggleDebug)
    self.accept('f5', self.doScreenshot)

    self.accept('x', self.toggleHeightfield)

    inputState.watchWithModifiers('forward', 'w')
    inputState.watchWithModifiers('left', 'a')
    inputState.watchWithModifiers('brake', 's')
    inputState.watchWithModifiers('right', 'd')
    inputState.watchWithModifiers('turnLeft', 'q')
    inputState.watchWithModifiers('turnRight', 'e')

    # Task
    taskMgr.add(self.update, 'updateWorld')
    self.accept('bullet-contact-added', self.onContactAdded)
    # self.accept('bullet-contact-destroyed', self.onContactDestroyed)

    # Physics -- Terrain
    self.setup()

    # Create Players
    self.createPlayers()

    # Camera
    self.setupCamera()

  def removeCollisionSet(self, arg):
    sleep(2)
    self.nodeFilterList.pop(0)

  # _____HANDLER_____
  def onContactAdded(self, node1, node2):
      if node1.notifiesCollisions() and node2.notifiesCollisions():
          isEnable = True
          list2 = [node1.getName(), node2.getName()]
          for nodeSet in self.nodeFilterList:
              if (list2[0] == nodeSet[0]) or (list2[0] == nodeSet[1]):
                  if (list2[1] == nodeSet[0]) or (list2[1] == nodeSet[1]):
                      isEnable = False

          if isEnable:
              npA = NodePath.anyPath(node1)
              npB = NodePath.anyPath(node2)
              message = ""
              if node1.getTag("isMe") == "True":
                  message = "Object-A is current player"
              if node2.getTag("isMe") == "True":
                  message = "Object-B is current player"
              print "-----------------------------------"
              print message
              print "Object-A: ", node1.getName()
              print "======== Mass: ", node1.getMass()
              print "======== Speed: ", node1.getLinearVelocity().length()
              print "Object-B: ", node2.getName()
              print "======== Mass: ", node2.getMass()
              print "======== Speed: ", node2.getLinearVelocity().length()
              print "Relative-heading (A -> B): ", npA.getTransform(npB).getHpr().getX()
              print "-----------------------------------"

              self.nodeFilterList.append((node1.getName(), node2.getName()))
              thread = Thread(target = self.removeCollisionSet, args = (1, ))
              self.collisionThreadSet.append(thread)
              thread.start()
            #   print "self.nodeFilterList: ", self.nodeFilterList

  def doExit(self):
    self.cleanup()
    sys.exit(1)

  def doReset(self):
    self.cleanup()
    self.setup()

  def toggleWireframe(self):
    base.toggleWireframe()

  def toggleTexture(self):
    base.toggleTexture()

  def toggleDebug(self):
    if self.debugNP.isHidden():
      self.debugNP.show()
    else:
      self.debugNP.hide()

  def doScreenshot(self):
    base.screenshot('Bullet')

  def toggleHeightfield(self):
    self.terrainContainer.setDebugEnabled()

  # ____TASK___
  def update(self, task):
    base.camera.lookAt(self.vehicleContainer.chassisNP)
    if inputState.isSet('turnLeft'):
        base.camera.setX(base.camera, -20 * globalClock.getDt())
    if inputState.isSet('turnRight'):
        base.camera.setX(base.camera, +20 * globalClock.getDt())
    # If the camera is too far from ralph, move it closer.
    # If the camera is too close to ralph, move it farther.
    camvec = self.vehicleContainer.chassisNP.getPos() - base.camera.getPos()
    camvec.setZ(0)
    camdist = camvec.length()
    camvec.normalize()
    if (camdist > 10.0):
      base.camera.setPos(base.camera.getPos() + camvec*(camdist-10))
      camdist = 10.0
    if (camdist < 5.0):
      base.camera.setPos(base.camera.getPos() - camvec*(5-camdist))
      camdist = 5.0

    # The camera should look in ralph's direction,
    # but it should also try to stay horizontal, so look at
    # a floater which hovers above ralph's head.
    self.floater.setPos(self.vehicleContainer.chassisNP.getPos())
    self.floater.setZ(self.vehicleContainer.chassisNP.getZ() + 2.0)
    base.camera.lookAt(self.floater)

    dt = globalClock.getDt()

    self.vehicleContainer.processInput(inputState, dt)
    self.moveCrazyCar(dt)
    self.world.doPhysics(dt, 10, 0.008)

    self.terrainContainer.terrain.update()

    return task.cont

  def moveCrazyCar(self, dt):
        move = path[self.pathCounter]
        self.crazyCar.updateMovement(move, dt)
        self.pathCounter += 1
        if self.pathCounter > len(path)-1:
            self.pathCounter = 0

  def cleanup(self):
    self.world = None
    self.worldNP.removeNode()

  def setupCamera(self):
    base.disableMouse()
    base.camera.setPos(self.vehicleContainer.chassisNP.getX(),self.vehicleContainer.chassisNP.getY()+10,2)
    # Create a floater object.  We use the "floater" as a temporary
    # variable in a variety of calculations.

    self.floater = NodePath(PandaNode("floater"))
    self.floater.reparentTo(render)

  def setupLights(self):
      base.setBackgroundColor(0.1, 0.1, 0.8, 1)
      base.setFrameRateMeter(True)

      # Light
      alight = AmbientLight('ambientLight')
      alight.setColor(Vec4(0.5, 0.5, 0.5, 1))
      alightNP = render.attachNewNode(alight)

      dlight = DirectionalLight('directionalLight')
      dlight.setDirection(Vec3(1, 1, -1))
      dlight.setColor(Vec4(0.7, 0.7, 0.7, 1))
      dlightNP = render.attachNewNode(dlight)

      render.clearLight()
      render.setLight(alightNP)
      render.setLight(dlightNP)

  def setup(self):
    self.worldNP = render.attachNewNode('World')

    # World
    self.debugNP = self.worldNP.attachNewNode(BulletDebugNode('Debug'))
    self.debugNP.show()
    self.debugNP.node().showNormals(True)

    self.world = BulletWorld()
    self.world.setGravity(Vec3(0, 0, -9.81))
    self.world.setDebugNode(self.debugNP.node())

    # Obstruction
    # self.obstruction = Obstruction(self)

    # Heightfield (static)
    self.terrainContainer = Terrain(self, base, render)

  def createPlayers(self):
    # Dynamic - moving bodies
    # Car
    self.vehicleContainer = Vehicle(self, isCurrentPlayer = True)
    ###### ONLY FOR TESTING ######
    self.pathCounter = 0
    self.crazyCar = Vehicle(self, LVecBase3(5, 5, 1))
    ###### ONLY FOR TESTING ######


game = Game()
run()
